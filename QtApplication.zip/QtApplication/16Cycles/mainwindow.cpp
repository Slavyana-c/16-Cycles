#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    QDir dir = QDir::current();
    QString dbpath = dir.currentPath();
    dbpath += "/../16Cycles/employees.db";
    db.setDatabaseName(dbpath);
   // db.setDatabaseName("/home/cserv1_a/soc_msc/ll16m23c/year2/Project/16-cycles/QtApplication/16Cycles/employees.db");
    ui-> dir-> setText(dbpath);

    if(db.open())
        ui-> labeldb-> setText("database open");
    else
        ui-> labeldb-> setText("not open");



}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QSqlQuery query(db);
    query.prepare("SELECT * FROM employees");
    query.exec();
    if(query.next())
        ui-> labeldb-> setText(query.value(1).toString());
    else
        ui-> labeldb-> setText("failure");
}
